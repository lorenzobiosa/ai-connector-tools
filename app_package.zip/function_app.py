# Azure Functions carica questo file come entrypoint
from src import app  # noqa: F401